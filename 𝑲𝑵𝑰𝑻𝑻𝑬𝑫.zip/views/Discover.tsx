
import React, { useState } from 'react';
import { searchCourses } from '../services/geminiService';
import { GroundingSource } from '../types';

export const Discover: React.FC = () => {
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<{ text: string; sources: GroundingSource[] } | null>(null);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query) return;
    setLoading(true);
    try {
      const res = await searchCourses(query);
      setResults(res);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-10 py-24">
      <div className="text-center mb-32 space-y-8">
        <h1 className="text-6xl md:text-8xl font-black uppercase tracking-tight-bold">Explore</h1>
        <p className="text-[11px] tracking-luxury text-gray-400 uppercase font-black">AI Knowledge Intelligence Search</p>
      </div>

      <form onSubmit={handleSearch} className="mb-40 relative group max-w-4xl mx-auto">
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="SEARCH THE FRONTIER..."
          className="w-full px-0 py-12 border-b-4 border-black/10 focus:border-black outline-none text-2xl lg:text-4xl font-black transition-all bg-transparent uppercase tracking-tight placeholder:text-black/5"
        />
        <button
          type="submit"
          disabled={loading}
          className="absolute right-0 bottom-12 text-[12px] font-black uppercase tracking-luxury hover:opacity-50 transition-opacity"
        >
          {loading ? 'Sourcing...' : 'Enter'}
        </button>
      </form>

      {results && (
        <div className="space-y-40 animate-in fade-in duration-1000">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-[10px] tracking-luxury font-black mb-12 uppercase text-black/20">Synthesized Findings</h2>
            <div className="text-[18px] leading-[2.2] tracking-tight text-black font-medium space-y-8">
              {results.text.split('\n').map((line, i) => (
                <p key={i}>{line}</p>
              ))}
            </div>
          </div>

          {results.sources.length > 0 && (
            <div className="border-t border-black/5 pt-20">
              <h3 className="text-[10px] tracking-luxury font-black text-black/20 uppercase mb-16">Verified Archive Sources</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                {results.sources.map((source, idx) => (
                  <a
                    key={idx}
                    href={source.uri}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="group border border-black/5 p-10 hover:border-black transition-all bg-white/20"
                  >
                    <div className="flex flex-col gap-4">
                      <span className="text-[10px] font-black tracking-widest text-black/30 uppercase">{new URL(source.uri).hostname}</span>
                      <h4 className="text-xl font-black uppercase tracking-tight group-hover:text-black">{source.title}</h4>
                      <div className="w-8 h-px bg-black/10 group-hover:w-full transition-all duration-700"></div>
                    </div>
                  </a>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
