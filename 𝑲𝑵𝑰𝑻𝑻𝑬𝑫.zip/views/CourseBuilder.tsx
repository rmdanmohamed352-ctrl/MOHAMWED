import React, { useState, useEffect } from 'react';
import { generateCurriculum } from '../services/geminiService';
import { Curriculum } from '../types';
import { CourseCard } from '../components/CourseCard';

const FEATURED_TRACKS = [
  { id: 'ai', title: 'AI & GENERATIVE DESIGN', level: 'Advanced' },
  { id: 'modular', title: 'MODULAR ENGINEERING', level: 'Intermediate' },
  { id: 'digital', title: 'DIGITAL ARCHIVE SYSTEMS', level: 'Beginner' }
];

export const CourseBuilder: React.FC = () => {
  const [topic, setTopic] = useState('');
  const [level, setLevel] = useState('Beginner');
  const [curriculum, setCurriculum] = useState<Curriculum | null>(null);
  const [loading, setLoading] = useState(false);

  const handleGenerate = async (e?: React.FormEvent, presetTopic?: string, presetLevel?: string) => {
    if (e) e.preventDefault();
    const targetTopic = presetTopic || topic;
    const targetLevel = presetLevel || level;
    
    if (!targetTopic) return;
    
    setLoading(true);
    setCurriculum(null);
    try {
      const res = await generateCurriculum(targetTopic, targetLevel);
      setCurriculum(res);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const selectTrack = (trackTopic: string, trackLevel: string) => {
    setTopic(trackTopic);
    setLevel(trackLevel);
    handleGenerate(undefined, trackTopic, trackLevel);
  };

  return (
    <div className="bg-[#F0EEE9] min-h-screen">
      {/* HEADER */}
      <section className="pt-64 pb-32 px-10 lg:px-24 border-b border-black/[0.03]">
        <div className="max-w-7xl mx-auto flex flex-col items-center text-center space-y-12">
          <span className="text-[9px] tracking-[1.5em] font-bold text-black/10 uppercase">Research Unit 02</span>
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-extralight uppercase tracking-[0.2em] leading-tight text-black">
            ACADEMY
          </h1>
          <div className="w-px h-24 bg-black/10"></div>
        </div>
      </section>

      {/* SPECIALIZATIONS */}
      <section className="py-24 px-10 lg:px-24 bg-white/40">
        <div className="max-w-7xl mx-auto">
          <div className="flex justify-between items-end mb-16">
            <h2 className="text-[10px] tracking-[0.8em] font-bold uppercase text-black/20">Archive Specializations</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {FEATURED_TRACKS.map((track) => (
              <button
                key={track.id}
                onClick={() => selectTrack(track.title, track.level)}
                className="group relative bg-[#F0EEE9] border border-black/5 p-12 text-left hover:border-black transition-all duration-700 overflow-hidden"
              >
                <span className="absolute -right-4 -bottom-8 text-8xl font-black italic text-black/[0.02] transition-all group-hover:text-black/[0.05] group-hover:-translate-y-4">
                  {track.id.toUpperCase()}
                </span>
                <span className="text-[7px] tracking-[0.6em] font-medium text-black/40 block mb-4">PATHWAY.LOG</span>
                <h3 className="text-xl font-bold italic brand-name" style={{ color: 'black', letterSpacing: '0.1em' }}>{track.title}</h3>
                <div className="mt-8 flex items-center justify-between">
                  <span className="text-[8px] tracking-[0.4em] font-medium uppercase opacity-30">{track.level}</span>
                  <span className="text-[8px] font-bold tracking-widest opacity-0 group-hover:opacity-100 transition-opacity">→ START</span>
                </div>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* CUSTOM BUILDER */}
      <section className="py-32 px-10 lg:px-24">
        <div className="max-w-4xl mx-auto">
          <div className="mb-24 text-center">
            <p className="text-[10px] text-black/30 tracking-[0.4em] uppercase font-light max-w-sm mx-auto">
              Define a custom knowledge objective to build a tailored learning path.
            </p>
          </div>
          
          <form onSubmit={handleGenerate} className="space-y-24">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-16">
              <div className="border-b border-black/10 pb-4">
                <label className="text-[7px] tracking-[0.8em] font-medium text-black/20 uppercase mb-4 block">Topic</label>
                <input
                  type="text"
                  value={topic}
                  onChange={(e) => setTopic(e.target.value)}
                  placeholder="E.G. GENERATIVE AI"
                  className="w-full bg-transparent outline-none text-sm font-light uppercase tracking-[0.2em] placeholder:text-black/5"
                />
              </div>
              <div className="border-b border-black/10 pb-4">
                <label className="text-[7px] tracking-[0.8em] font-medium text-black/20 uppercase mb-4 block">Experience Level</label>
                <select
                  value={level}
                  onChange={(e) => setLevel(e.target.value)}
                  className="w-full bg-transparent outline-none text-sm font-light uppercase tracking-[0.2em] appearance-none cursor-pointer"
                >
                  <option>Beginner</option>
                  <option>Intermediate</option>
                  <option>Advanced</option>
                </select>
              </div>
            </div>
            <button
              type="submit"
              disabled={loading}
              className="w-full bg-black text-white py-12 text-[9px] font-medium uppercase tracking-[1em] hover:bg-white hover:text-black border border-black transition-all duration-700"
            >
              {loading ? 'ANALYZING KNOWLEDGE...' : 'CONSTRUCT CURRICULUM'}
            </button>
          </form>
        </div>
      </section>

      {/* RESULTS */}
      {curriculum && (
        <section className="pb-64 px-10 lg:px-24 animate-in fade-in slide-in-from-bottom-8 duration-1000">
          <div className="max-w-7xl mx-auto">
            <div className="mb-32 border-l border-black pl-16 py-8">
              <div className="flex items-center gap-8 mb-8">
                <span className="text-[8px] tracking-[1em] font-bold text-white bg-black px-6 py-2 uppercase">{curriculum.level}</span>
                <span className="text-[8px] tracking-[0.6em] text-black/20 font-medium uppercase">VER.2026.01</span>
              </div>
              <h2 className="text-4xl lg:text-6xl font-light uppercase tracking-tight leading-tight mb-8">
                {curriculum.title}
              </h2>
              <p className="text-[13px] font-light uppercase tracking-[0.3em] leading-[2.5] text-black/40 max-w-3xl">
                {curriculum.summary}
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12">
              {curriculum.modules.map((mod, idx) => (
                <CourseCard key={mod.id} module={mod} index={idx} />
              ))}
            </div>
          </div>
        </section>
      )}

      {loading && (
        <div className="py-64 flex flex-col items-center justify-center space-y-12">
          <div className="w-px h-32 bg-black/10 animate-pulse"></div>
          <span className="text-[8px] tracking-[2em] uppercase font-bold text-black/20 animate-pulse">Processing Data</span>
        </div>
      )}
    </div>
  );
};