import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';

export const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const location = useLocation();
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 30);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'SHOP', path: '/' },
    { name: 'DNA', path: '/identity' },
    { name: 'LEARN', path: '/academy' },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-[#F0EEE9]">
      <nav className={`fixed top-0 w-full z-50 transition-all duration-1000 px-10 lg:px-24 flex items-center justify-between ${
        isScrolled ? 'h-16 bg-[#F0EEE9]/90 backdrop-blur-md border-b border-black/[0.02]' : 'h-32 bg-transparent'
      }`}>
        <div className="flex-1 hidden md:flex items-center space-x-12">
          {navLinks.map((link) => (
            <Link
              key={link.path}
              to={link.path}
              className={`text-[7px] tracking-[0.6em] uppercase transition-all duration-700 font-medium ${
                location.pathname === link.path ? 'opacity-90' : 'opacity-20 hover:opacity-60'
              } text-black`}
            >
              {link.name}
            </Link>
          ))}
        </div>

        <Link to="/" className="absolute left-1/2 -translate-x-1/2 group flex flex-col items-center">
          <span className="text-[9px] brand-name opacity-80 group-hover:opacity-100 group-hover:tracking-[0.2em] transition-all duration-700">𝙆𝙉𝙄𝙏𝙏𝙀𝘿</span>
          <span className="text-[4px] tracking-[0.8em] font-light text-black/20 mt-1 opacity-0 group-hover:opacity-100 transition-opacity duration-1000 uppercase">Archive System</span>
        </Link>

        <div className="flex-1 flex justify-end items-center gap-10">
          <Link to="/discover" className="text-black opacity-15 hover:opacity-100 transition-opacity">
            <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.7" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
          </Link>
        </div>
      </nav>

      <main className="flex-grow">
        {children}
      </main>

      <footer className="py-32 px-10 lg:px-24 border-t border-black/[0.03] bg-transparent">
        <div className="max-w-[1400px] mx-auto flex justify-between items-center text-[5px] tracking-[1.2em] uppercase font-light text-black/10">
          <div className="font-bold italic brand-name" style={{ fontSize: '7px', letterSpacing: '0.4em' }}>𝙆𝙉𝙄𝙏𝙏𝙀𝘿 SYSTEM</div>
          <div>EST. 2026</div>
        </div>
      </footer>
    </div>
  );
};