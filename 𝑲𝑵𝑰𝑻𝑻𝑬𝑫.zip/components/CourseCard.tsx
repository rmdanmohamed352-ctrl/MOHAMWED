
import React from 'react';
import { LearningModule } from '../types';

interface Props {
  module: LearningModule;
  index: number;
}

export const CourseCard: React.FC<Props> = ({ module, index }) => {
  return (
    <div className="group bg-white/40 border-2 border-black/5 p-10 hover:border-black transition-all flex flex-col h-full">
      <div className="flex justify-between items-start mb-12">
        <span className="text-[10px] font-black tracking-luxury text-black/20 uppercase">Module {index + 1}</span>
        <span className="text-[9px] font-black tracking-luxury uppercase bg-black text-white px-4 py-1">
          {module.duration}
        </span>
      </div>
      
      <h3 className="text-2xl font-black uppercase tracking-tight mb-8 group-hover:translate-x-2 transition-transform">{module.title}</h3>
      
      <p className="text-[13px] font-medium leading-[2] tracking-widest text-black/50 uppercase mb-12 flex-1">
        {module.description}
      </p>

      <div className="flex flex-wrap gap-4 border-t border-black/5 pt-8">
        {module.topics.map((topic, i) => (
          <span key={i} className="text-[9px] font-black tracking-widest uppercase text-black/30">
            {topic}
          </span>
        ))}
      </div>
    </div>
  );
};
