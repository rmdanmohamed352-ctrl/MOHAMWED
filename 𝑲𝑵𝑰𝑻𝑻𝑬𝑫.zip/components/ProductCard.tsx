import React from 'react';
import { Product } from '../types';

interface Props {
  product: Product;
}

const CATEGORY_THUMBNAILS: Record<string, string> = {
  'Man': 'https://images.unsplash.com/photo-1618354691373-d851c5c3a990?auto=format&fit=crop&q=80&w=800',
  'Woman': 'https://images.unsplash.com/photo-1594938298603-c8148c4dae35?auto=format&fit=crop&q=80&w=800',
  'Tech': 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&q=80&w=800',
  'Utility': 'https://images.unsplash.com/photo-1523381210434-271e8be1f52b?auto=format&fit=crop&q=80&w=800',
  'Default': 'https://images.unsplash.com/photo-1512436991641-6745cdb1723f?auto=format&fit=crop&q=80&w=800'
};

export const ProductCard: React.FC<Props> = ({ product }) => {
  const thumbUrl = CATEGORY_THUMBNAILS[product.category] || CATEGORY_THUMBNAILS['Default'];

  return (
    <div className="group flex flex-col bg-transparent relative cursor-pointer">
      <div className="relative overflow-hidden aspect-[4/5] bg-white mb-6 border border-black/[0.02] shadow-sm transition-all duration-700 group-hover:shadow-xl group-hover:shadow-black/5">
        <img
          src={thumbUrl}
          alt={product.name}
          className="w-full h-full object-cover transition-all duration-[1500ms] group-hover:scale-110 opacity-90"
        />
        
        <div className="absolute inset-0 bg-[#F0EEE9]/5 opacity-0 group-hover:opacity-100 transition-opacity flex items-end justify-center p-8 pointer-events-none">
          <span className="text-[7px] tracking-[1.2em] text-black uppercase font-medium bg-white/95 px-8 py-4 shadow-sm translate-y-4 group-hover:translate-y-0 transition-all duration-700">
            VIEW DETAILS
          </span>
        </div>
      </div>

      <div className="px-2 space-y-4">
        <div className="flex justify-between items-start">
          <div className="space-y-2">
            <h3 className="text-[9px] font-medium tracking-[0.5em] uppercase text-black/80 leading-relaxed group-hover:text-black transition-colors">{product.name}</h3>
            <span className="text-[7px] text-black/20 font-light tracking-[0.6em] uppercase block">{product.category} Archive</span>
          </div>
          <div className="text-right">
             <span className="text-[10px] font-medium tracking-tight text-black/60">${product.price.toLocaleString()}</span>
          </div>
        </div>
        
        <div className="flex items-center gap-6">
          <div className="h-[0.5px] flex-1 bg-black/[0.04]"></div>
          <div className="text-[5px] font-light text-black/10 uppercase tracking-[0.8em]">ITEM.REF {product.id.slice(0, 4)}</div>
        </div>
      </div>
    </div>
  );
};