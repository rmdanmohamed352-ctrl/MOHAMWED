import React from 'react';

export const Identity: React.FC = () => {
  const sections = [
    {
      id: "01",
      title: "Vibe",
      desc: "Raw. Modular. Unfiltered.",
      details: "We build for the street, not the runway. High performance, zero hype."
    },
    {
      id: "02",
      title: "Gear",
      desc: "Street Utility.",
      details: "Every detail matters. Weather-proof, tech-focused, and made to move."
    },
    {
      id: "03",
      title: "Fam",
      desc: "For the Crew.",
      details: "Made for those who move through the city. Real gear for real explorers."
    }
  ];

  return (
    <div className="bg-[#F0EEE9] min-h-screen pt-48">
      <section className="py-96 px-10 lg:px-24 max-w-7xl mx-auto">
        <div className="text-center mb-128 space-y-12">
          <span className="text-[9px] font-black tracking-[0.8em] text-black/20 uppercase">STREET.DOC 01</span>
          <h1 className="text-5xl lg:text-7xl font-light uppercase tracking-[0.2em]">The DNA</h1>
          <div className="w-px h-32 bg-black mx-auto mt-20 opacity-10"></div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-32">
          {sections.map((section) => (
            <div key={section.id} className="border-t border-black/[0.05] pt-12 space-y-16 group">
              <div className="flex justify-between items-baseline">
                <span className="text-[10px] font-medium text-black opacity-30 tracking-luxury">{section.id}</span>
                <span className="text-[8px] font-medium text-black/10 uppercase tracking-widest">VER.01</span>
              </div>
              <h3 className="text-4xl font-light uppercase tracking-tight group-hover:translate-x-4 transition-transform duration-1000">{section.title}</h3>
              <p className="text-[14px] font-light uppercase tracking-[0.2em] leading-relaxed opacity-60">{section.desc}</p>
              <p className="text-[11px] font-light uppercase tracking-[0.3em] text-black/40 leading-[3]">
                {section.details}
              </p>
            </div>
          ))}
        </div>
      </section>

      <section className="py-[180px] bg-white/20 border-y border-black/[0.03] overflow-hidden">
        <div className="max-w-[1400px] mx-auto grid grid-cols-1 lg:grid-cols-2 gap-48 items-center px-10">
          <div className="aspect-square bg-[#F0EEE9] relative grayscale flex items-center justify-center p-20 shadow-sm">
             <div className="absolute inset-10 border border-black/[0.02]"></div>
             <img 
              src="https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&q=80&w=1200" 
              className="w-full h-full object-cover opacity-50 mix-blend-multiply" 
              alt="The Core"
             />
             <div className="absolute bottom-12 right-12 text-[7px] font-medium tracking-[0.6em] text-black/30 uppercase">FIG. 01 / CORE</div>
          </div>
          <div className="space-y-24 pl-10">
            <h2 className="text-5xl lg:text-7xl font-light uppercase tracking-tight leading-[1.2] text-black/80">The Street<br/>Archive</h2>
            <div className="h-px w-32 bg-black/[0.05] my-10"></div>
            <p className="text-[12px] text-black/40 font-light uppercase tracking-[0.4em] leading-[3.2]">
              KNITTED exists for urban life. We merge raw street energy with clean architectural design. No shortcuts.
            </p>
          </div>
        </div>
      </section>

      <section className="py-[180px] px-10 text-center">
        <div className="max-w-xl mx-auto space-y-12">
          <p className="text-xl font-light uppercase tracking-[0.4em] leading-relaxed text-black/60">
            STREET FIRST.
          </p>
          <div className="w-12 h-px bg-black mx-auto opacity-10"></div>
        </div>
      </section>
    </div>
  );
};