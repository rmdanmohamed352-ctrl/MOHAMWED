import React, { useState, useRef, useEffect } from 'react';
import { startConciergeSession } from '../services/geminiService';
import { ChatMessage } from '../types';

export const Concierge: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    { role: 'model', content: "ONLINE. HOW CAN I HELP WITH YOUR STYLE TODAY?" }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const chatRef = useRef<any>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const getChat = () => {
    if (!chatRef.current) {
      chatRef.current = startConciergeSession();
    }
    return chatRef.current;
  };

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input || loading) return;

    const userMessage = input;
    setInput('');
    setMessages(prev => [...prev, { role: 'user', content: userMessage }]);
    setLoading(true);

    try {
      const chat = getChat();
      const result = await chat.sendMessage({ message: userMessage });
      setMessages(prev => [...prev, { role: 'model', content: result.text || "TRY AGAIN." }]);
    } catch (err) {
      setMessages(prev => [...prev, { role: 'model', content: "ERROR." }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#F0EEE9] py-64 px-10 lg:px-24">
      <div className="max-w-4xl mx-auto flex flex-col min-h-[75vh]">
        <div className="text-center mb-48 space-y-8">
          <h1 className="text-5xl lg:text-6xl font-black uppercase tracking-tight-bold">Chat</h1>
          <p className="text-[10px] uppercase tracking-[0.4em] text-black/30 font-bold">Ask anything about the collection.</p>
        </div>

        <div 
          ref={scrollRef}
          className="flex-1 space-y-16 overflow-y-auto mb-24 pr-6 scrollbar-hide"
        >
          {messages.map((msg, idx) => (
            <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[85%] ${msg.role === 'user' ? 'text-right' : 'text-left'}`}>
                <p className="text-[9px] tracking-widest mb-4 opacity-20 uppercase font-black">
                  {msg.role === 'user' ? 'You' : 'System'}
                </p>
                <div className={`text-[14px] leading-[2.6] tracking-widest font-bold uppercase ${msg.role === 'user' ? 'text-black' : 'text-gray-500'}`}>
                  {msg.content}
                </div>
              </div>
            </div>
          ))}
          {loading && (
            <div className="flex justify-start">
              <span className="text-[10px] tracking-widest text-black/10 animate-pulse font-black uppercase">Thinking...</span>
            </div>
          )}
        </div>

        <form onSubmit={handleSend} className="relative group w-full border-t border-black pt-12">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="ASK..."
            className="w-full px-0 py-8 outline-none transition-all placeholder:text-black/5 text-[11px] tracking-[0.5em] focus:placeholder:opacity-0 bg-transparent uppercase font-bold"
          />
          <button
            type="submit"
            disabled={loading || !input}
            className="absolute right-0 top-12 py-8 text-[10px] font-black uppercase tracking-widest disabled:opacity-10 group-hover:text-black transition-all"
          >
            Send
          </button>
        </form>
      </div>
    </div>
  );
};