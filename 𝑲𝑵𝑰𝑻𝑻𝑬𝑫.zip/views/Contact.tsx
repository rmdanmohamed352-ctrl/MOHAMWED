import React from 'react';

export const Contact: React.FC = () => {
  return (
    <div className="max-w-2xl mx-auto px-6 py-24 text-center">
      <div className="mb-20">
        <h1 className="text-5xl font-black uppercase mb-6 tracking-tight-bold">Say Hello</h1>
        <p className="text-[11px] text-gray-400 uppercase leading-relaxed max-w-lg mx-auto tracking-widest font-bold">
          Get in touch for gear advice or shop questions.
        </p>
      </div>

      <form className="space-y-12 text-left">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          <div className="border-b border-black/10 py-2">
            <label className="text-[9px] uppercase tracking-[0.2em] font-black text-gray-400 block mb-2">Name</label>
            <input type="text" className="w-full bg-transparent outline-none text-[12px] tracking-widest uppercase font-bold" placeholder="Your Name" />
          </div>
          <div className="border-b border-black/10 py-2">
            <label className="text-[9px] uppercase tracking-[0.2em] font-black text-gray-400 block mb-2">Email</label>
            <input type="email" className="w-full bg-transparent outline-none text-[12px] tracking-widest uppercase font-bold" placeholder="Email Address" />
          </div>
        </div>
        
        <div className="border-b border-black/10 py-2">
          <label className="text-[9px] uppercase tracking-[0.2em] font-black text-gray-400 block mb-2">Subject</label>
          <select className="w-full bg-transparent outline-none text-[11px] tracking-widest uppercase font-bold text-black appearance-none">
            <option>Gear Question</option>
            <option>Shop Support</option>
            <option>Drop Info</option>
            <option>Collab</option>
          </select>
        </div>

        <div className="border-b border-black/10 py-2">
          <label className="text-[9px] uppercase tracking-[0.2em] font-black text-gray-400 block mb-2">Message</label>
          <textarea rows={4} className="w-full bg-transparent outline-none text-[12px] tracking-widest uppercase font-bold resize-none" placeholder="Details..."></textarea>
        </div>

        <button className="w-full bg-black text-white py-6 text-[11px] font-black uppercase tracking-[0.4em] hover:bg-gray-800 transition-colors">
          Send
        </button>
      </form>

      <div className="mt-32 grid grid-cols-1 md:grid-cols-3 gap-12 text-[10px] tracking-[0.2em] uppercase font-black text-gray-300">
        <div>
          <p className="text-black mb-2">Berlin</p>
        </div>
        <div>
          <p className="text-black mb-2">Tokyo</p>
        </div>
        <div>
          <p className="text-black mb-2">New York</p>
        </div>
      </div>
    </div>
  );
};