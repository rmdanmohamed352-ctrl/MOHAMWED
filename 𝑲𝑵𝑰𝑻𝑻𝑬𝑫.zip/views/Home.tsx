import React, { useState, useEffect } from 'react';
import { ProductCard } from '../components/ProductCard';
import { generateCollection } from '../services/geminiService';
import { Product } from '../types';

const HERO_IMAGES: Record<string, string> = {
  'All': 'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&q=80&w=2400',
  'Man': 'https://images.unsplash.com/photo-1505022610485-0249ba5b3675?auto=format&fit=crop&q=80&w=2400',
  'Woman': 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&q=80&w=2400',
  'Tech': 'https://images.unsplash.com/photo-1523381210434-271e8be1f52b?auto=format&fit=crop&q=80&w=2400',
  'Utility': 'https://images.unsplash.com/photo-1591047139829-d91aecb6caea?auto=format&fit=crop&q=80&w=2400'
};

export const Home: React.FC = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeCategory, setActiveCategory] = useState('All');

  useEffect(() => {
    const fetchInitial = async () => {
      setLoading(true);
      try {
        const res = await generateCollection(activeCategory === 'All' ? "Modern Streetwear" : `${activeCategory} Drop`);
        setProducts(res);
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    };
    fetchInitial();
  }, [activeCategory]);

  return (
    <div className="bg-[#F0EEE9] selection:bg-black selection:text-white">
      {/* 01. HERO */}
      <section className="relative h-screen w-full flex flex-col items-center justify-center overflow-hidden border-b border-black/[0.03]">
        <div className="absolute inset-0 opacity-[0.15] transition-all duration-[3000ms]">
          <img 
            key={activeCategory}
            src={HERO_IMAGES[activeCategory] || HERO_IMAGES['All']} 
            alt="Editorial"
            className="w-full h-full object-cover animate-in fade-in zoom-in-105 duration-1000"
          />
        </div>
        
        <div className="relative z-10 flex flex-col items-center text-center px-6">
          <h1 className="text-2xl md:text-3xl brand-name -mt-16 tracking-[0.4em] transition-all duration-1000">
            {activeCategory === 'All' ? '𝙆𝙉𝙄𝙏𝙏𝙀𝘿' : activeCategory}
          </h1>
          <div className="mt-16 w-px h-24 bg-black/10"></div>
        </div>
        
        <div className="absolute bottom-12 left-1/2 -translate-x-1/2 flex flex-col items-center gap-4">
          <span className="text-[6px] tracking-[1em] text-black/20 uppercase font-medium">explore archive</span>
        </div>
      </section>

      {/* 02. FILTERS */}
      <section className="sticky top-0 z-40 bg-[#F0EEE9]/95 backdrop-blur-sm border-b border-black/[0.03] py-8">
        <div className="max-w-[1400px] mx-auto px-10 lg:px-24">
          <ul className="flex justify-center md:justify-start gap-8 md:gap-16 text-[8px] uppercase tracking-[0.4em] font-medium">
            {['All', 'Man', 'Woman', 'Tech', 'Utility'].map((cat) => (
              <li 
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`cursor-pointer transition-all duration-500 pb-2 border-b ${activeCategory === cat ? 'text-black border-black/30' : 'text-black/20 border-transparent hover:text-black/60'}`}
              >
                {cat}
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* 03. VISION */}
      <section className="py-48 md:py-96 px-10 flex flex-col items-center text-center">
        <div className="max-w-2xl space-y-8">
          <span className="text-[7px] tracking-[1em] font-bold text-black/10 uppercase">The Vision</span>
          <h2 className="text-lg md:text-2xl font-extralight leading-relaxed text-black/80 tracking-[0.3em] uppercase">
            Built for the street.<br/>Designed for for life.
          </h2>
          <p className="text-[10px] text-black/30 leading-loose tracking-[0.4em] font-light uppercase max-w-sm mx-auto">
            Modular gear for the city. Clean forms, tough fabrics, zero noise.
          </p>
        </div>
      </section>

      {/* 04. SHOP */}
      <section className="pb-[180px] max-w-[1400px] mx-auto px-10 lg:px-24">
        <div className="flex flex-col gap-32">
          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-24">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <div key={i} className="aspect-[4/5] bg-white border border-black/5 animate-pulse"></div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-12 gap-y-32">
              {products.map((p, index) => (
                <div key={p.id} className={`${index % 3 === 1 ? 'md:mt-24' : ''}`}>
                  <ProductCard product={p} />
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* 05. STORE */}
      <section className="relative py-[200px] bg-white px-10 lg:px-24 border-t border-black/[0.03]">
        <div className="max-w-[1200px] mx-auto flex flex-col lg:flex-row items-center gap-64">
          <div className="w-full lg:w-1/2 aspect-[3/4] overflow-hidden shadow-2xl shadow-black/[0.02] group">
            <img 
              src="https://images.unsplash.com/photo-1567401893414-76b7b1e5a7a5?auto=format&fit=crop&q=80&w=2400" 
              alt="Boutique"
              className="w-full h-full object-cover opacity-60 transition-transform duration-[2000ms] group-hover:scale-105"
            />
          </div>
          <div className="w-full lg:w-1/2 space-y-16">
            <span className="text-[7px] tracking-[1em] font-medium uppercase text-black/20">Archive Locations</span>
            <h2 className="text-4xl lg:text-6xl font-extralight uppercase tracking-tight leading-[1.1] text-black/80">
              THE<br/>STORE
            </h2>
            <p className="text-[11px] text-black/40 leading-[3] tracking-[0.3em] font-light uppercase max-sm">
              Visit our flagships. Modular spaces for a modular collection.
            </p>
            <div className="pt-12">
              <button className="text-[8px] tracking-[0.8em] font-medium uppercase border-b border-black/20 pb-2 hover:border-black transition-all">Find a space</button>
            </div>
          </div>
        </div>
      </section>

      {/* 06. NEWSLETTER */}
      <section className="py-[150px] bg-[#F0EEE9] px-10 text-center">
        <div className="max-w-xl mx-auto space-y-12">
          <span className="text-[7px] font-bold tracking-[1.5em] uppercase text-black/10">Stay Updated</span>
          <h3 className="text-2xl font-extralight uppercase tracking-[0.4em] text-black/60">Join us</h3>
          <p className="text-[9px] text-black/30 tracking-[0.6em] uppercase">Early access and limited drops.</p>
          <div className="flex flex-col md:flex-row gap-4 pt-12">
            <input 
              type="email" 
              placeholder="YOUR EMAIL" 
              className="flex-1 bg-transparent border-b border-black/10 outline-none text-[10px] tracking-[0.4em] py-4 placeholder:text-black/5 uppercase font-light"
            />
            <button className="bg-black text-white px-12 py-4 text-[9px] tracking-[1em] uppercase font-medium hover:bg-white hover:text-black border border-black transition-all duration-700">Join</button>
          </div>
        </div>
      </section>
    </div>
  );
};