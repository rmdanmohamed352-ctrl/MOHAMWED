import { GoogleGenAI, Type } from "@google/genai";
import { Product, Curriculum, GroundingSource } from "../types";

export const generateCollection = async (style: string): Promise<Product[]> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Generate a list of 6 technical streetwear products for an urban collection called: ${style}. Include oversized fits, modular components, and technical fabrics. Return realistic prices in USD between $80 and $1200.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            id: { type: Type.STRING },
            name: { type: Type.STRING },
            price: { type: Type.NUMBER },
            category: { type: Type.STRING },
            description: { type: Type.STRING },
            image: { type: Type.STRING, description: "A descriptive keyword for a street-style photo, e.g., 'oversized black technical cargo pants'" }
          },
          required: ["id", "name", "price", "category", "description", "image"]
        }
      }
    }
  });

  return JSON.parse(response.text || '[]');
};

export const startConciergeSession = () => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  return ai.chats.create({
    model: 'gemini-3-flash-preview',
    config: {
      systemInstruction: "You are a lead consultant for 'KNITTED STREET GROUP'. You specialize in advanced technical streetwear, urban utility, and modular fashion systems. You help users build 'street archives'—wardrobes that are functional, durable, and culturally relevant. Your tone is direct, knowledgeable, and slightly edgy."
    }
  });
};

export const searchCourses = async (query: string): Promise<{ text: string; sources: GroundingSource[] }> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: `Find the best resources for street culture, technical design, and urban fashion systems: ${query}. Provide a structured recommendation.`,
    config: {
      tools: [{ googleSearch: {} }],
    },
  });

  const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
  const sources: GroundingSource[] = groundingChunks
    .filter((chunk: any) => chunk.web)
    .map((chunk: any) => ({
      uri: chunk.web.uri,
      title: chunk.web.title,
    }));

  return {
    text: response.text || '',
    sources,
  };
};

export const generateCurriculum = async (topic: string, level: string): Promise<Curriculum> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: `Generate a detailed learning path for: ${topic}. 
    Focus on Street Culture, Technical Fashion, and Advanced Design Systems. 
    If the topic is AI or Digital Design, focus heavily on Generative AI (Midjourney, Stable Diffusion), CLO3D, and the future of automated manufacturing.
    Level: ${level}.
    Structure the modules to be practical, architectural, and innovative.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          level: { type: Type.STRING },
          summary: { type: Type.STRING },
          modules: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                id: { type: Type.STRING },
                title: { type: Type.STRING },
                duration: { type: Type.STRING },
                description: { type: Type.STRING },
                topics: { type: Type.ARRAY, items: { type: Type.STRING } }
              },
              required: ["id", "title", "duration", "description", "topics"]
            }
          }
        },
        required: ["title", "level", "summary", "modules"]
      }
    }
  });

  return JSON.parse(response.text || '{}');
};

export const startTutorSession = (systemInstruction: string) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  return ai.chats.create({
    model: 'gemini-3-pro-preview',
    config: {
      systemInstruction: "You are an expert Mentor in AI-Driven Streetwear Culture and Digital Design. You teach users how to leverage generative AI, 3D modeling (CLO3D), and technical pattern-making. Your tone is intellectual, avant-garde, and encouraging.",
    }
  });
};